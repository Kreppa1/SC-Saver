!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!! WARNING: THIS MAY BE CONSIDERED MALWARE BY WINDOWS, this script uses a real BSOD to crash your PC              !!
!! by killing the svchost.exe task in the background. This is infact pretty harmless and I hadn't any issues yet. !!
!! However, only run this script on you own risk!                                                                 !!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

========================
Welcome to School-Saver
========================

This is School-Saver, it helps you in "I forgot my homework" situations,
as long as you use a windows device for your notes.

This script simply checks for the task you selected, and will crash your windows
device as soon as this task has been found running in the background.

So be carefull and use the test feature first, to check if your selected
task is running at the moment already.